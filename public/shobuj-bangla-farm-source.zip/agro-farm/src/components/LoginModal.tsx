import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { User } from '../types';
import { 
  Lock, 
  Mail, 
  ShieldCheck, 
  Briefcase, 
  UserCheck, 
  Wallet, 
  ArrowRight, 
  X, 
  KeyRound,
  Eye,
  EyeOff
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const LoginModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { db, login, language } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Look for matching user in db
    const cleanEmail = email.trim().toLowerCase();
    const foundUser = db.users.find(
      (u) => u.email.toLowerCase() === cleanEmail
    );

    if (foundUser) {
      login(foundUser);
      onClose();
    } else {
      setError(
        language === 'bn' 
          ? 'এই ইমেইল দিয়ে কোনো অ্যাকাউন্ট পাওয়া যায়নি। নিচের ডেমো অ্যাকাউন্টগুলো থেকে বেছে নিন।' 
          : 'No user found with this email. Please select from the demo accounts below.'
      );
    }
  };

  const handleQuickLogin = (user: User) => {
    login(user);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 to-emerald-900 px-6 py-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-xs flex items-center justify-center border border-white/20">
              <Lock className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <h3 className="font-bold text-lg leading-tight">
                {language === 'bn' ? 'লগইন করুন' : 'Secure Sign In'}
              </h3>
              <p className="text-xs text-emerald-200 mt-0.5">
                {language === 'bn' ? 'সবুজ বাংলা এগ্রো ফার্ম পোর্টাল' : 'Shobuj Bangla Agro Portal'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {error && (
            <div className="p-3 text-xs bg-rose-50 border border-rose-200 text-rose-800 rounded-lg">
              {error}
            </div>
          )}

          {/* Regular Login Form */}
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                {language === 'bn' ? 'ইমেইল অ্যাড্রেস' : 'Email Address'}
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@agrofarm.com / kabir@investor.com"
                  className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600 outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                {language === 'bn' ? 'পাসওয়ার্ড' : 'Password'}
              </label>
              <div className="relative">
                <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-10 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600 outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm rounded-lg shadow-sm transition-colors flex items-center justify-center gap-2"
            >
              <span>{language === 'bn' ? 'প্রবেশ করুন' : 'Sign In'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Quick Demo Accounts */}
          <div className="pt-2">
            <div className="relative flex py-2 items-center">
              <div className="flex-grow border-t border-slate-200"></div>
              <span className="flex-shrink mx-3 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                {language === 'bn' ? 'অথবা দ্রুত টেস্ট করতে ডেমো ক্লিক করুন' : 'Or Quick 1-Click Demo Login'}
              </span>
              <div className="flex-grow border-t border-slate-200"></div>
            </div>

            <div className="grid grid-cols-1 gap-2 mt-2">
              {db.users.slice(0, 4).map((u) => {
                let RoleIconComp = ShieldCheck;
                let badgeColor = 'text-amber-700 bg-amber-50 border-amber-200';
                let roleLabel = 'Super Admin';

                if (u.role === 'super_admin') {
                  RoleIconComp = ShieldCheck;
                  roleLabel = language === 'bn' ? 'সুপার অ্যাডমিন (এমডি)' : 'Super Admin / MD';
                  badgeColor = 'text-amber-700 bg-amber-50 border-amber-200';
                } else if (u.role === 'accountant') {
                  RoleIconComp = Briefcase;
                  roleLabel = language === 'bn' ? 'হিসাবরক্ষক (Accountant)' : 'Chief Accountant';
                  badgeColor = 'text-blue-700 bg-blue-50 border-blue-200';
                } else if (u.role === 'sector_manager') {
                  RoleIconComp = UserCheck;
                  roleLabel = language === 'bn' ? 'খামার ম্যানেজার' : 'Sector Manager';
                  badgeColor = 'text-emerald-700 bg-emerald-50 border-emerald-200';
                } else if (u.role === 'investor') {
                  RoleIconComp = Wallet;
                  roleLabel = language === 'bn' ? 'বিনিয়োগকারী (Investor)' : 'Verified Investor';
                  badgeColor = 'text-purple-700 bg-purple-50 border-purple-200';
                }

                return (
                  <button
                    key={u.id}
                    onClick={() => handleQuickLogin(u)}
                    type="button"
                    className="w-full flex items-center justify-between p-2.5 rounded-xl border border-slate-200 hover:border-emerald-600 hover:bg-emerald-50/50 transition-all text-left group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center shrink-0 group-hover:bg-emerald-100 transition-colors">
                        <RoleIconComp className="w-4 h-4 text-slate-700 group-hover:text-emerald-700" />
                      </div>
                      <div className="truncate">
                        <div className="text-xs font-semibold text-slate-900 truncate">
                          {u.name}
                        </div>
                        <div className="text-[11px] text-slate-500 truncate">
                          {u.email}
                        </div>
                      </div>
                    </div>
                    <span className={`text-[10px] font-medium px-2 py-0.5 rounded border shrink-0 ${badgeColor}`}>
                      {roleLabel}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
